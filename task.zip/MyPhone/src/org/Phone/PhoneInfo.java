package org.Phone;

public class PhoneInfo {
	public void phoneName() {
		System.out.println("PhoneName = redmi");
	}
	public void phonemieiNum() {
		System.out.println ("PhonemieiNum = 123");
	}
	public void camera() {
		System.out.println("camera = 48mp");
		
	}
	public void storage() {
		System.out.println("storage = 512gp");
	}
	public void osName() {
		System.out.println("OSName = snapdragon 8");
	}

}
