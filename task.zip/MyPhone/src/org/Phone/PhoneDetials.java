package org.Phone;

public class PhoneDetials {
	public static void main(String [] args) {
		PhoneInfo p = new PhoneInfo();
		p.phoneName();
		p.phonemieiNum();
		p.camera();
		p.storage();
		p.osName();
	}
}
