package org.emp;

public class EmployeeDetials {
	public static void main(String[] arg ) {
		Employee e = new Employee();
		
		e.empID();
		e.empName();
		e.empDOB();
		e.empEmail();
		e.empPhone();
		e.empAdress();
		
	}

}
