package org.emp;

public class Employee {
   public void empID () {
	   System.out.println("EmployeeID = 3112");
   }
   public void empName() {
	   System.out.println("EmployeeName = vimanthan");
	   }
   public void empDOB() {
	   System.out.println("EmployeeDOB = 28/09/2000");
   }
   public void empEmail() {
	   System.out.println("EmployeeEmail = vimanthan3112@gmail.com");
   }
   public void empAdress() {
	   System.out.println("EmployeeAdress = chennai"); 
	   }
   public void empPhone() {
	   System.out.println("EmployeePhone = 1231231");
   }
}
