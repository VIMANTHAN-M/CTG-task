package org.company;

public class CompanyInfo {
	public void companyName() {
		System.out.println ("CompanyName = ABC");
	}
	public void companyID() {
		System.out.println ("CompanyId = 3112");
	}
	public void companyAddress() {
		System.out.println ("CompanyAddress = chennai");
	}

}
