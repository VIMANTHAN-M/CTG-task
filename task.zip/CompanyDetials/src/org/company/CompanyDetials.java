package org.company;

public class CompanyDetials {
	public static void main(String [] args) {
		CompanyInfo c = new CompanyInfo();
		c.companyName();
		c.companyID();
		c.companyAddress();
	}

}
