package org.Adress;

public class CtgAdress {
	public static void main(String [] args) {
		CtgTech c = new CtgTech();
		c.ctgadayar();
		c.ctgannanagar();
		c.ctgomr();
		c.ctgvelacherry();
		c.ctgTambaram();
				
	}

}
