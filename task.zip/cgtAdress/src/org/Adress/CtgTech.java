package org.Adress;

public class CtgTech {
	public void ctgomr () {
		System.out.println ("CTG OMR");
	}
	public void ctgadayar() {
		System.out.println ("CTG Adayar");
	}
	public void ctgTambaram() {
		System.out.println ("CTG Tambaram");
	}
	public void ctgvelacherry() {
		System.out.println("CTG Velacherry");
	}
	public void ctgannanagar() {
		System.out.println ("CTG Annanagar");
		
	}

}
